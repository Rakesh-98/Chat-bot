# SecureChat — Private 2-Person Chat (PWA)

## Kya hai
- Sirf **Admin** ID bana sakta hai. Public signup nahi hai.
- Admin 2 IDs ko **pair** karta hai; sirf wahi do aapas me chat kar sakte hain.
- Realtime (Socket.IO), typing + online status.
- Messages database me **AES-256-GCM** se encrypted. Password **bcrypt** hash. Login brute-force limit. HTTPS forced.
- Admin panel se message **nahi padh** sakta.
- Phone me "Install / Add to Home Screen" se app jaisa chalta hai.

## Deploy (Render.com — step by step)
1. github.com par naya **private** repo banao, is folder ki saari files upload karo.
2. render.com → New → **Web Service** → repo chuno.
   - Build Command: `npm install`   |  Start Command: `npm start`
3. **Environment** me ye variables daalo (.env.example dekho):
   `ADMIN_USER`, `ADMIN_PASS`, `JWT_SECRET`, `ENC_KEY`, `DB_PATH=/data/chat.db`
   (JWT_SECRET/ENC_KEY: 64+ random characters. **ENC_KEY baad me badla to purane messages nahi khulenge.**)
4. **Disk** add karo: Mount Path `/data`, 1GB (paid plan). Bina disk ke free plan par restart par data (users/messages) ud jata hai.
   Alternative: Railway / Fly.io me Volume lagao, ya apna VPS.
5. Deploy hone par `https://aapka-app.onrender.com` milega.

## Phone par install
- **Android (Chrome):** link kholo → ⋮ menu → *Install app / Add to Home screen*.
- **iPhone (Safari):** link kholo → Share → *Add to Home Screen*.

## SOP (Standard Operating Procedure)

### A. Admin — nayi ID banana
1. Admin ID/password se login karo → Admin Panel.
2. "Nayi ID banao" me username + strong password (min 8) daalo → Create.
3. Dusre person ke liye bhi same karo.
4. "Do users ko jodo" me dono chuno → **Pair karo**.
5. ID + password har person ko **alag, surakshit tarike se** do (call/in-person). Pehli login ke baad password reset karwana ho to admin se "Password reset" karwao.

### B. User — chat shuru karna
1. App link kholo, Home Screen par install karo.
2. Mili hui ID + password se login.
3. Upar partner ka naam dikhega; message likho → ➤.

### C. Admin — maintenance
- **Pair badalna:** Unpair → naya Pair.
- **Password bhoola:** Password reset button.
- **ID band karna:** Delete (ID + uske messages hamesha ke liye delete, user turant logout).
- **Admin password badalna:** hosting me `ADMIN_PASS` change karo → redeploy.
- **Backup:** `/data/chat.db` ka regular backup lo.

### D. Security checklist
- Repo **private** rakho; `.env` kabhi upload mat karo.
- Password kisi ko WhatsApp/SMS par mat bhejo; share karne ke baad reset karwa do.
- Phone me screen lock rakho; shak ho to admin se ID delete/reset karwao.
- Hosting account par 2FA on rakho (server owner technically DB access rakhta hai).

### E. Local test
```
npm install
ADMIN_USER=admin ADMIN_PASS=Admin@12345 JWT_SECRET=abc123abc123abc123abc123abc123 ENC_KEY=xyz789xyz789xyz789xyz789xyz789 npm start
```
Browser: http://localhost:3000
