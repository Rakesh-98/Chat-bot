const C='sc-v1',F=['/','/manifest.json'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(F)));self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(clients.claim()));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.pathname.startsWith('/api')||u.pathname.startsWith('/socket.io'))return;
 e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)))});
