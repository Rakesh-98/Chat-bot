const express=require('express'),http=require('http'),{Server}=require('socket.io'),Database=require('better-sqlite3'),
bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),crypto=require('crypto'),path=require('path');
const {JWT_SECRET,ENC_KEY,ADMIN_USER,ADMIN_PASS}=process.env;
if(!JWT_SECRET||!ENC_KEY||!ADMIN_USER||!ADMIN_PASS){console.error('ENV missing: ADMIN_USER, ADMIN_PASS, JWT_SECRET, ENC_KEY');process.exit(1)}
const KEY=crypto.createHash('sha256').update(ENC_KEY).digest();
const db=new Database(process.env.DB_PATH||'chat.db');
db.exec(`create table if not exists users(id integer primary key autoincrement,username text unique,hash text,role text default 'user',partner_id integer);
create table if not exists messages(id integer primary key autoincrement,sender integer,receiver integer,data blob,iv blob,tag blob,ts integer);`);
// admin seed / sync
const ah=bcrypt.hashSync(ADMIN_PASS,10);
if(db.prepare('select id from users where role=?').get('admin'))db.prepare("update users set username=?,hash=? where role='admin'").run(ADMIN_USER,ah);
else db.prepare("insert into users(username,hash,role) values(?,?,'admin')").run(ADMIN_USER,ah);

const enc=t=>{const iv=crypto.randomBytes(12),c=crypto.createCipheriv('aes-256-gcm',KEY,iv);const d=Buffer.concat([c.update(t,'utf8'),c.final()]);return{d,iv,tag:c.getAuthTag()}};
const dec=r=>{try{const c=crypto.createDecipheriv('aes-256-gcm',KEY,r.iv);c.setAuthTag(r.tag);return Buffer.concat([c.update(r.data),c.final()]).toString('utf8')}catch{return '[unreadable]'}};
const sign=u=>jwt.sign({id:u.id},JWT_SECRET,{expiresIn:'30d'});
const getUser=id=>db.prepare('select id,username,role,partner_id from users where id=?').get(id);
const userFromToken=t=>{try{return getUser(jwt.verify(t,JWT_SECRET).id)}catch{return null}};

const app=express(),server=http.createServer(app),io=new Server(server,{maxHttpBufferSize:1e5});
app.set('trust proxy',1);app.use(express.json({limit:'10kb'}));
app.use((q,s,n)=>{s.set({'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Cache-Control':'no-store'});
 if(q.headers['x-forwarded-proto']==='http')return s.redirect('https://'+q.headers.host+q.url);n()});
app.use(express.static(path.join(__dirname,'public'),{setHeaders:(r,p)=>{if(p.endsWith('.png')||p.endsWith('.json'))r.setHeader('Cache-Control','public,max-age=3600')}}));

const tries=new Map();
const auth=(role)=>(q,s,n)=>{const u=userFromToken((q.headers.authorization||'').replace('Bearer ',''));
 if(!u||(role&&u.role!==role))return s.status(401).json({error:'Not allowed'});q.user=u;n()};

app.post('/api/login',(q,s)=>{
 const k=q.ip,t=tries.get(k)||{n:0,ts:Date.now()};if(Date.now()-t.ts>9e5){t.n=0;t.ts=Date.now()}
 if(t.n>=8)return s.status(429).json({error:'Bahut attempts. 15 min baad try karo.'});
 const {username,password}=q.body||{};const u=db.prepare('select * from users where username=?').get(String(username||''));
 if(!u||!bcrypt.compareSync(String(password||''),u.hash)){t.n++;tries.set(k,t);return s.status(401).json({error:'ID ya password galat hai'})}
 tries.delete(k);s.json({token:sign(u),user:{id:u.id,username:u.username,role:u.role}});
});
app.get('/api/me',auth(),(q,s)=>{const p=q.user.partner_id?getUser(q.user.partner_id):null;s.json({user:q.user,partner:p&&{id:p.id,username:p.username}})});
app.get('/api/messages',auth('user'),(q,s)=>{const m=q.user.id,p=q.user.partner_id;if(!p)return s.json([]);
 const rows=db.prepare('select * from messages where (sender=? and receiver=?) or (sender=? and receiver=?) order by id desc limit 300').all(m,p,p,m).reverse();
 s.json(rows.map(r=>({id:r.id,from:r.sender,text:dec(r),ts:r.ts})))});

// ---- admin ----
app.get('/api/admin/users',auth('admin'),(q,s)=>s.json(db.prepare("select u.id,u.username,u.partner_id,p.username partner from users u left join users p on p.id=u.partner_id where u.role='user'").all()));
app.post('/api/admin/users',auth('admin'),(q,s)=>{const {username,password}=q.body||{};
 if(!/^[a-zA-Z0-9_.-]{3,30}$/.test(username||'')||String(password||'').length<8)return s.status(400).json({error:'ID 3-30 chars (a-z,0-9,_.-) aur password min 8 chars'});
 try{db.prepare("insert into users(username,hash) values(?,?)").run(username,bcrypt.hashSync(password,10));s.json({ok:1})}catch{s.status(409).json({error:'Ye ID pehle se hai'})}});
const unpair=id=>{const u=getUser(id);if(u&&u.partner_id)db.prepare('update users set partner_id=null where id in (?,?)').run(u.id,u.partner_id)};
app.post('/api/admin/pair',auth('admin'),(q,s)=>{const a=+q.body.a,b=+q.body.b;const A=getUser(a),B=getUser(b);
 if(!A||!B||a===b||A.role!=='user'||B.role!=='user')return s.status(400).json({error:'Do alag users chuno'});
 unpair(a);unpair(b);db.prepare('update users set partner_id=? where id=?').run(b,a);db.prepare('update users set partner_id=? where id=?').run(a,b);
 [a,b].forEach(i=>io.to('u'+i).emit('repair'));s.json({ok:1})});
app.post('/api/admin/unpair',auth('admin'),(q,s)=>{const a=+q.body.a;const u=getUser(a);unpair(a);if(u&&u.partner_id)io.to('u'+u.partner_id).emit('repair');io.to('u'+a).emit('repair');s.json({ok:1})});
app.post('/api/admin/password',auth('admin'),(q,s)=>{const {id,password}=q.body||{};if(String(password||'').length<8)return s.status(400).json({error:'Min 8 chars'});
 db.prepare("update users set hash=? where id=? and role='user'").run(bcrypt.hashSync(password,10),+id);s.json({ok:1})});
app.delete('/api/admin/users/:id',auth('admin'),(q,s)=>{const id=+q.params.id;unpair(id);
 db.prepare("delete from messages where sender=? or receiver=?").run(id,id);db.prepare("delete from users where id=? and role='user'").run(id);
 io.in('u'+id).disconnectSockets(true);s.json({ok:1})});

// ---- realtime ----
io.use((sk,n)=>{const u=userFromToken(sk.handshake.auth&&sk.handshake.auth.token);if(!u)return n(new Error('auth'));sk.user=u;n()});
const online=async id=>(await io.in('u'+id).fetchSockets()).length>0;
io.on('connection',async sk=>{
 const me=sk.user;sk.join('u'+me.id);
 if(me.role!=='user')return;
 const notify=async()=>{const u=getUser(me.id);if(u&&u.partner_id){io.to('u'+u.partner_id).emit('presence',await online(me.id));sk.emit('presence',await online(u.partner_id))}};
 notify();
 sk.on('send',t=>{const u=getUser(me.id);if(!u||!u.partner_id||typeof t!=='string')return;t=t.trim().slice(0,2000);if(!t)return;
  const e=enc(t),ts=Date.now();const r=db.prepare('insert into messages(sender,receiver,data,iv,tag,ts) values(?,?,?,?,?,?)').run(u.id,u.partner_id,e.d,e.iv,e.tag,ts);
  const m={id:r.lastInsertRowid,from:u.id,text:t,ts};io.to('u'+u.id).to('u'+u.partner_id).emit('msg',m)});
 sk.on('typing',()=>{const u=getUser(me.id);if(u&&u.partner_id)io.to('u'+u.partner_id).emit('typing')});
 sk.on('disconnect',async()=>{const u=getUser(me.id);if(u&&u.partner_id)io.to('u'+u.partner_id).emit('presence',await online(me.id))});
});
server.listen(process.env.PORT||3000,()=>console.log('SecureChat running'));
